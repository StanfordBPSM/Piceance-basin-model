PBtopo_big.txt:
grid map 1-min resolution.
http://maps.ngdc.noaa.gov/viewers/wcs-client/