http://certmapper.cr.usgs.gov/data/noga00/prov20/spatial/doc/pr2003dptg.htm

Spatial_Domain:
Bounding_Coordinates:
West_Bounding_Coordinate: -112.00
East_Bounding_Coordinate: -105.75
North_Bounding_Coordinate: 41.00
South_Bounding_Coordinate: 38.00

Logical_Consistency_Report:
The depth map to the top of the Dakota Sandstone is a direct result of subtracting two, 2-dimensional surface grids - 
the topographic surface of the Uinta-Piceance Province area, in the format of a Digital Elevation Model (DEM), 
minus the surface of the top of the Dakota Sandstone. 
Both of these surface grids were generated using Dynamic Graphics' EarthVision modeling software (v. 5).
Completeness_Report:
The data used for the structure contour map on top of the Dakota Sandstone includes data from oil and gas wells, data from digital geologic maps of Utah and Colorado, and thickness data of overlying stratigraphic units where data for the Dakota are sparse. The grid for the structure on top of the Dakota Sandstone was subtracted from the grid of the surface, which resulted in a grid for the depth to the top of the Dakota.