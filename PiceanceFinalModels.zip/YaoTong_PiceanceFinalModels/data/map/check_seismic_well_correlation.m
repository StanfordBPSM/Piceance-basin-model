cd E:\PB3D_May14\data\map
clear all
close all
welldata = load('ALL_Dakota.CU_grid.dat');
newwell = welldata(welldata(:,3)~=99999,3);
seismic = load('PointMap_dakota_grid_9well.dat');
newseis = seismic(welldata(:,3)~=99999,3);
% find(welldata(:,3)~=99999)
figure
scatter(newwell,newseis)
text(1000,5,['R = ',num2str(corr(newwell,newseis))])
%%
welldata = load('ALL_MVRD.CU_grid.dat');
newwell = welldata(welldata(:,3)~=99999,3);
seismic = load('PointMap_mesaverde_grid_9well.dat');
newseis = seismic(welldata(:,3)~=99999,3);
% find(welldata(:,3)~=99999)
figure
scatter(newwell,newseis)
text(0,5,['R = ',num2str(corr(newwell,newseis))])